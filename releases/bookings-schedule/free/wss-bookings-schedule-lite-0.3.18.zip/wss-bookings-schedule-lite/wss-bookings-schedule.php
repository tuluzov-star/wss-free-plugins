<?php
/**
 * Plugin Name: WSS Bookings Schedule Lite
 * Description: Витрина расписания для booking-товаров WooCommerce. Совместима с WSS WooCommerce Bookings и WooCommerce Bookings.
 * Version: 0.3.18
 * Author: WSS
 * Author URI: https://website-support.ru/
 * Update URI: https://website-support.ru/plugins/wss-bookings-schedule/
 * Text Domain: wss-bookings-schedule
 * Domain Path: /languages
 * WC requires at least: 7.0
 * WC tested up to: 11.1
 * Requires Plugins: woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/includes/wss-i18n.php';
WSS_Plugin_I18n_202609::register(__FILE__, 'wss-bookings-schedule');
require_once __DIR__ . '/includes/class-wss-update-cache-control.php';
WSS_Update_Cache_Control_20260915::register( 'wss_bs_free_update_info' );

define( 'WSS_BS_VERSION', '0.3.18' );
define( 'WSS_BS_FILE', __FILE__ );
define( 'WSS_BS_DIR', plugin_dir_path( __FILE__ ) );
define( 'WSS_BS_URL', plugin_dir_url( __FILE__ ) );
require_once WSS_BS_DIR . 'includes/class-wss-bs-updater.php';
require_once WSS_BS_DIR . 'includes/admin-inline-script.php';
require_once WSS_BS_DIR . 'includes/frontend-inline-script.php';
define( 'WSS_BS_IS_PRO', false );
define( 'WSS_BS_UPGRADE_URL', 'https://website-support.ru/plugins/wss-bookings-schedule/' );

require_once WSS_BS_DIR . 'includes/class-wss-bs-plugin.php';
require_once WSS_BS_DIR . 'includes/class-wss-bs-settings.php';
require_once WSS_BS_DIR . 'includes/class-wss-bs-shortcode.php';
require_once WSS_BS_DIR . 'includes/class-wss-bs-query.php';

add_action(
    'admin_enqueue_scripts',
    static function ( $hook_suffix ) {
        // Pro owns the schedule/admin runtime when both packages are active.
        // Lite stays active as the paired Free/base package and keeps its updater.
        if ( defined( 'WSS_BSP_VERSION' ) ) {
            return;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        $is_booking_page = false !== strpos( $page, 'booking' ) || false !== strpos( $page, 'schedule' );
        $is_woocommerce_page = false !== strpos( (string) $hook_suffix, 'woocommerce' );

        if ( ! $is_booking_page && ! $is_woocommerce_page ) {
            return;
        }

        wp_enqueue_style(
            'wss-bookings-schedule-admin-tools',
            WSS_BS_URL . 'assets/css/admin-tools.css',
            array(),
            WSS_BS_VERSION
        );
        wp_register_script(
            'wss-bookings-schedule-admin-tools',
            false,
            array( 'wp-i18n' ),
            WSS_BS_VERSION,
            true
        );
        wp_enqueue_script( 'wss-bookings-schedule-admin-tools' );
        wp_add_inline_script( 'wss-bookings-schedule-admin-tools', wss_bs_get_admin_inline_script(), 'after' );
    }
);

register_activation_hook( __FILE__, array( 'WSS_BS_Plugin', 'activate' ) );

if ( class_exists( 'WSS_BS_Updater' ) ) {
	new WSS_BS_Updater(
		WSS_BS_FILE,
		WSS_BS_VERSION,
		'https://website-support.ru/plugins/wss-bookings-schedule/'
	);
}

add_action(
    'plugins_loaded',
    static function (): void {
        // Avoid duplicate shortcode/settings runtime when Pro is active.
        if ( defined( 'WSS_BSP_VERSION' ) ) {
            return;
        }
        WSS_BS_Plugin::init();
    },
    20
);
