=== WSS Order Status Colors for WooCommerce ===
Contributors: wss
Tags: woocommerce, orders, statuses, admin, colors
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.4
License: GPLv2 or later

Цветовое выделение заказов WooCommerce в админке по статусам.

== Описание ==

Free-версия позволяет назначить цвет фона и цвет текста для существующих статусов WooCommerce. Поддерживается классический список заказов и HPOS-экран WooCommerce → Заказы.

С версии 1.1.0 добавлена настройка цвета кнопок внутри окрашенных строк заказов. Это полезно для кастомных кнопок в колонках заказа, например CRM Contact, View Contact или других действий.

Pro-дополнение добавляет создание собственных статусов заказов, управление статусами и активацию лицензии.

== Установка ==

1. Установите ZIP через Плагины → Добавить новый → Загрузить плагин.
2. Активируйте плагин.
3. Откройте WooCommerce → Цвета заказов.

== Changelog ==

= 1.1.4 =
* Обновление окраски строк после AJAX теперь выполняется через стандартное событие jQuery без MutationObserver всего документа.
* Снижен риск ложных эвристических срабатываний антивирусов.


= 1.1.0 =
* Добавлена вкладка «Кнопки в заказах».
* Добавлена настройка фона, текста, рамки, hover-цветов и скругления кнопок в окрашенных строках.

= 1.0.0 =
* Первый релиз.



## 1.1.2 — English localization

English PHP and JavaScript translations are bundled. Russian remains available.
Existing plugin directory and main file are unchanged.
