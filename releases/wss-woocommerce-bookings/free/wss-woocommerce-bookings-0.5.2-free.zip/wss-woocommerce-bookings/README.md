# WSS WooCommerce Bookings Free

Бесплатное ядро бронирований для WooCommerce.

## Возможности Free

- Включение бронирования у товара WooCommerce.
- Ручное добавление слотов расписания.
- Простой генератор слотов по выбранным датам.
- Календарь на фронте.
- Кнопки времени и выбор количества билетов.
- Проверка вместимости и запись даты/времени в заказ.

## Pro-расширение

Pro добавляет импорт из WooCommerce Bookings, массовые действия, блокировки дат, календарь броней, списки гостей, экспорт, типы билетов, режим “весь день” и настройки внешнего вида.



## 0.5.2 — English localization

English PHP and JavaScript translations are bundled. Russian remains available.
Existing plugin directory and main file are unchanged.
